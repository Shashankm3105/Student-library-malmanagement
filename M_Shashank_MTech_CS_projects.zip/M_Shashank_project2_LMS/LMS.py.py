import tkinter as tk
from tkinter import messagebox

def authenticate():
    username = entry_username.get()
    password = entry_password.get()

    # Check if username and password are correct
    if username == "admin" and password == "password":
        messagebox.showinfo("Login Successful", "Welcome, " + username + "!")
    else:
        messagebox.showerror("Login Failed", "Invalid username or password")

# Create the main window
root = tk.Tk()
root.title("Login Page")

# Create labels and entry widgets
label_username = tk.Label(root, text="Username:")
label_username.grid(row=0, column=0, sticky="E")
entry_username = tk.Entry(root)
entry_username.grid(row=0, column=1)

label_password = tk.Label(root, text="Password:")
label_password.grid(row=1, column=0, sticky="E")
entry_password = tk.Entry(root, show="*")
entry_password.grid(row=1, column=1)

# Create login button
login_button = tk.Button(root, text="Login", command=authenticate)
login_button.grid(row=2, columnspan=2)

# Run the main event loop
root.mainloop()
